// NoAds: системный блокировщик рекламы для jailbreak iOS.
// Три слоя: DNS (getaddrinfo), сетевые задачи/WebView, скрытие рекламных view.

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <netdb.h>
#import <objc/runtime.h>

// ---------- Список рекламных доменов (суффиксное совпадение) ----------
static NSArray<NSString *> *AdDomains(void) {
    static NSArray *list;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        list = @[
            // Google
            @"doubleclick.net", @"googlesyndication.com", @"googleadservices.com",
            @"adservice.google.com", @"admob.com", @"2mdn.net", @"googletagservices.com",
            // Сети и медиаторы
            @"applovin.com", @"applvn.com", @"unityads.unity3d.com", @"adcolony.com",
            @"vungle.com", @"inmobi.com", @"chartboost.com", @"ironsrc.com",
            @"supersonicads.com", @"mopub.com", @"tapjoy.com", @"startappservice.com",
            @"mintegral.com", @"mtgglobals.com", @"smaato.net", @"pangleglobal.com",
            @"criteo.com", @"criteo.net", @"taboola.com", @"outbrain.com",
            @"adnxs.com", @"rubiconproject.com", @"pubmatic.com", @"openx.net",
            @"an.facebook.com",
            // Россия / СНГ
            @"an.yandex.ru", @"yabs.yandex.ru", @"adfox.ru", @"adriver.ru",
            @"begun.ru", @"ad.mail.ru", @"mytarget.com", @"mytracker.com"
        ];
    });
    return list;
}

static BOOL HostIsBlocked(NSString *host) {
    if (host.length == 0) return NO;
    host = host.lowercaseString;
    for (NSString *d in AdDomains()) {
        if ([host isEqualToString:d] || [host hasSuffix:[@"." stringByAppendingString:d]])
            return YES;
    }
    return NO;
}

// ---------- Слой 1: DNS. Ловит почти всё, включая SDK на сокетах ----------
%hookf(int, getaddrinfo, const char *node, const char *service,
       const struct addrinfo *hints, struct addrinfo **res) {
    if (node && HostIsBlocked([NSString stringWithUTF8String:node])) {
        return EAI_NONAME;
    }
    return %orig;
}

// ---------- Слой 2а: сетевые задачи ----------
%hook NSURLSessionTask
- (void)resume {
    NSURL *url = self.currentRequest.URL ?: self.originalRequest.URL;
    if (HostIsBlocked(url.host)) {
        [self cancel];
        return;
    }
    %orig;
}
%end

// ---------- Слой 2б: WKWebView (сеть у него вне процесса, нужны правила) ----------
static WKContentRuleList *gRuleList;
static BOOL gCompiling;

static NSString *RulesJSON(void) {
    NSMutableArray *rules = [NSMutableArray array];
    for (NSString *d in AdDomains()) {
        NSString *esc = [d stringByReplacingOccurrencesOfString:@"." withString:@"\\."];
        [rules addObject:@{
            @"trigger": @{ @"url-filter": [NSString stringWithFormat:@"^https?://([^/]+\\.)?%@([/:?]|$)", esc] },
            @"action": @{ @"type": @"block" }
        }];
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:rules options:0 error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

static void AttachRules(WKWebViewConfiguration *cfg) {
    if (!cfg) return;
    if (gRuleList) {
        [cfg.userContentController addContentRuleList:gRuleList];
        return;
    }
    if (gCompiling) return;
    gCompiling = YES;
    [[WKContentRuleListStore defaultStore]
        compileContentRuleListForIdentifier:@"NoAdsRules"
                     encodedContentRuleList:RulesJSON()
                          completionHandler:^(WKContentRuleList *list, NSError *err) {
        gCompiling = NO;
        if (list) {
            gRuleList = list;
            dispatch_async(dispatch_get_main_queue(), ^{
                [cfg.userContentController addContentRuleList:list];
            });
        }
    }];
}

%hook WKWebView
- (instancetype)initWithFrame:(CGRect)frame configuration:(WKWebViewConfiguration *)configuration {
    AttachRules(configuration);
    return %orig;
}
%end

// ---------- Слой 3: скрытие рекламных view и показ полноэкранных ----------
%group AdViews

%hook UIView
- (void)didMoveToWindow {
    %orig;
    if (!self.window) return;
    static NSArray *prefixes;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        prefixes = @[@"GADBannerView", @"GADNativeAdView", @"GADMediaView",
                     @"FBAdView", @"FBNativeAd", @"ALAdView", @"MPAdView",
                     @"IMBanner", @"ISBannerView", @"BUBannerAdView",
                     @"BUNativeExpress", @"YMABannerAdView", @"YMANativeAdView"];
    });
    NSString *name = NSStringFromClass(object_getClass(self));
    for (NSString *p in prefixes) {
        if ([name hasPrefix:p]) {
            self.hidden = YES;
            self.alpha = 0;
            self.userInteractionEnabled = NO;
            break;
        }
    }
}
%end

// Полноэкранная реклама AdMob (награждаемую не трогаем, иначе ломаются бонусы)
%hook GADInterstitialAd
- (void)presentFromRootViewController:(UIViewController *)vc {
    // no-op
}
%end

%end

%ctor {
    NSString *proc = NSProcessInfo.processInfo.processName;
    if ([proc isEqualToString:@"SpringBoard"]) return;
    %init;
    %init(AdViews);
}
